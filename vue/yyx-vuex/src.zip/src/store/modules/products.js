import shop from '../../api/shop'
const state = {
  all:[
  
  ]
}

const getters = {}
// vuex 给actions的， commit mutations
const actions = {
  getAllProducts( {commit}) {
    // api
    shop.getProducts((products) => {
      console.log('前端到api，callback 回来了')

    })
    // mutations

  }
}

const mutations = {}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}